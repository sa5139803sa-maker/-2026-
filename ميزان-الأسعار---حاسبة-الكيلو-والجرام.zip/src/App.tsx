import React, {useEffect, useState} from 'react';
import {
  Bookmark,
  Calculator,
  Moon,
  Scale,
  Sun,
  TableProperties,
  X,
} from 'lucide-react';
import {OfflineIndicator} from './components/OfflineIndicator';
import {PWAInstallButton} from './components/PWAInstallButton';
import {QuickWeightsPanel} from './components/QuickWeightsPanel';
import {SavedItem, SavedItemsPanel} from './components/SavedItemsPanel';
import {ScaleCalculator} from './components/ScaleCalculator';
import {parsePositiveNumber, SHEKEL_SYMBOL} from './utils/formatters';

type MobileTab = 'calculator' | 'weights' | 'saved';

const SUGGESTED_ITEM_NAMES = ['لحم', 'دجاج', 'قهوة', 'جبن', 'مكسرات', 'عسل', 'توابل'];

export default function App() {
  const [kiloPriceInput, setKiloPriceInput] = useState<string>(() => {
    try {
      return localStorage.getItem('mizan_kilo_price') ?? '';
    } catch {
      return '';
    }
  });

  const [targetAmountInput, setTargetAmountInput] = useState<string>(() => {
    try {
      return localStorage.getItem('mizan_target_amount') ?? '';
    } catch {
      return '';
    }
  });

  const [targetGramsInput, setTargetGramsInput] = useState<string>('250');

  const [savedItems, setSavedItems] = useState<SavedItem[]>(() => {
    try {
      const raw = localStorage.getItem('mizan_saved_items');
      return raw ? (JSON.parse(raw) as SavedItem[]) : [];
    } catch {
      return [];
    }
  });

  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof document !== 'undefined') {
      return document.documentElement.classList.contains('dark');
    }
    return false;
  });

  const [mobileTab, setMobileTab] = useState<MobileTab>('calculator');
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [newItemName, setNewItemName] = useState('');

  useEffect(() => {
    try {
      localStorage.setItem('mizan_kilo_price', kiloPriceInput);
    } catch {
      // Storage unavailable
    }
  }, [kiloPriceInput]);

  useEffect(() => {
    try {
      localStorage.setItem('mizan_target_amount', targetAmountInput);
    } catch {
      // Storage unavailable
    }
  }, [targetAmountInput]);

  useEffect(() => {
    try {
      localStorage.setItem('mizan_saved_items', JSON.stringify(savedItems));
    } catch {
      // Storage unavailable
    }
  }, [savedItems]);

  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle('dark', next);
    try {
      localStorage.setItem('mizan_theme', next ? 'dark' : 'light');
    } catch {
      // Storage unavailable
    }
  };

  const activeKiloPrice = parsePositiveNumber(kiloPriceInput);

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newItemName.trim();
    if (!trimmed || activeKiloPrice <= 0) return;

    const item: SavedItem = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: trimmed,
      kiloPrice: activeKiloPrice,
    };
    setSavedItems((prev) => [item, ...prev]);
    setNewItemName('');
    setShowSaveModal(false);
  };

  const handleDeleteItem = (id: string) => {
    setSavedItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleSelectSavedItem = (item: SavedItem) => {
    setKiloPriceInput(String(item.kiloPrice));
    setMobileTab('calculator');
  };

  const handleSelectPriceFromWeight = (price: string) => {
    setTargetAmountInput(price);
    setMobileTab('calculator');
  };

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-[#F7F8F7] text-zinc-900 dark:bg-[#0B1110] dark:text-zinc-100">
      {/* Compact Top App Bar (48px) */}
      <header className="z-30 h-12 shrink-0 border-b border-zinc-200/80 bg-white/85 backdrop-blur-md dark:border-zinc-800/80 dark:bg-[#0F1715]/85">
        <div className="mx-auto flex h-full max-w-5xl items-center justify-between gap-4 px-3 sm:px-6">
          {/* Brand */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#0D7A5F] text-white dark:bg-emerald-600">
              <Scale className="h-4 w-4" aria-hidden="true" />
            </div>
            <h1 className="font-display text-sm font-bold tracking-tight text-zinc-900 whitespace-nowrap sm:text-base dark:text-zinc-50">
              ميزان الأسعار
            </h1>
          </div>

          {/* Header Controls */}
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="px-2 text-xs font-semibold text-zinc-600 dark:text-zinc-300">
              شيكل ({SHEKEL_SYMBOL})
            </span>

            <button
              type="button"
              onClick={toggleTheme}
              className="flex h-10 w-10 items-center justify-center rounded-xl text-zinc-600 transition-colors hover:bg-zinc-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D7A5F] dark:text-zinc-300 dark:hover:bg-zinc-800"
              aria-label={isDark ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن'}
            >
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>

            <PWAInstallButton />
          </div>
        </div>
      </header>

      {/* Main Content Workspace - Fits exact remaining viewport height without outer scroll */}
      <main className="mx-auto flex min-h-0 w-full max-w-5xl flex-1 flex-col px-3 py-2.5 sm:px-6 sm:py-4">
        <div className="flex h-full min-h-0 flex-1 flex-col lg:grid lg:grid-cols-12 lg:gap-5">
          <div
            className={`min-h-0 flex-1 lg:col-span-7 lg:block lg:h-full ${
              mobileTab === 'calculator' ? 'flex flex-col' : 'hidden'
            }`}
          >
            <ScaleCalculator
              kiloPriceInput={kiloPriceInput}
              onKiloPriceChange={setKiloPriceInput}
              targetAmountInput={targetAmountInput}
              onTargetAmountChange={setTargetAmountInput}
              targetGramsInput={targetGramsInput}
              onTargetGramsChange={setTargetGramsInput}
              currencySymbol={SHEKEL_SYMBOL}
              onOpenSaveModal={() => setShowSaveModal(true)}
            />
          </div>

          <div
            className={`min-h-0 flex-col gap-3.5 lg:col-span-5 lg:grid lg:h-full lg:grid-rows-[1.25fr_1fr] lg:gap-4 ${
              mobileTab === 'calculator' ? 'hidden lg:grid' : 'flex flex-1'
            }`}
          >
            <div
              className={`min-h-0 ${
                mobileTab === 'weights' ? 'flex flex-1 flex-col' : 'hidden lg:flex lg:flex-col'
              }`}
            >
              <QuickWeightsPanel
                kiloPriceInput={kiloPriceInput}
                currencySymbol={SHEKEL_SYMBOL}
                onSelectAmountFromWeight={handleSelectPriceFromWeight}
              />
            </div>

            <div
              className={`min-h-0 ${
                mobileTab === 'saved' ? 'flex flex-1 flex-col' : 'hidden lg:flex lg:flex-col'
              }`}
            >
              <SavedItemsPanel
                items={savedItems}
                currencySymbol={SHEKEL_SYMBOL}
                activeKiloPrice={activeKiloPrice}
                onSelectItem={handleSelectSavedItem}
                onDeleteItem={handleDeleteItem}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Mobile Bottom Tab Bar (52px) */}
      <nav
        aria-label="التنقل الرئيسي"
        className="z-30 h-[52px] shrink-0 border-t border-zinc-200/80 bg-white/90 backdrop-blur-md lg:hidden dark:border-zinc-800/80 dark:bg-[#0F1715]/90"
      >
        <div className="mx-auto grid h-full max-w-md grid-cols-3 items-center">
          <button
            type="button"
            onClick={() => setMobileTab('calculator')}
            className={`flex h-full flex-col items-center justify-center gap-0.5 transition-colors ${
              mobileTab === 'calculator'
                ? 'text-[#0D7A5F] dark:text-emerald-400'
                : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <Calculator className="h-4.5 w-4.5" aria-hidden="true" />
            <span className="text-[11px] font-semibold">الحاسبة</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileTab('weights')}
            className={`flex h-full flex-col items-center justify-center gap-0.5 transition-colors ${
              mobileTab === 'weights'
                ? 'text-[#0D7A5F] dark:text-emerald-400'
                : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <TableProperties className="h-4.5 w-4.5" aria-hidden="true" />
            <span className="text-[11px] font-semibold">جدول الأوزان</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileTab('saved')}
            className={`flex h-full flex-col items-center justify-center gap-0.5 transition-colors ${
              mobileTab === 'saved'
                ? 'text-[#0D7A5F] dark:text-emerald-400'
                : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <Bookmark className="h-4.5 w-4.5" aria-hidden="true" />
            <span className="text-[11px] font-semibold">
              المحفوظات{savedItems.length > 0 ? ` (${savedItems.length})` : ''}
            </span>
          </button>
        </div>
      </nav>

      {/* Save Item Bottom Sheet / Modal */}
      {showSaveModal && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-xs sm:items-center sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="save-item-title"
          onClick={() => setShowSaveModal(false)}
        >
          <form
            onSubmit={handleSaveItem}
            className="w-full max-w-md rounded-t-3xl bg-white p-5 shadow-xl sm:rounded-3xl sm:p-6 dark:bg-[#131B19]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-zinc-300 sm:hidden dark:bg-zinc-700" />
            <div className="flex items-center justify-between">
              <h2 id="save-item-title" className="text-base font-bold text-zinc-900 dark:text-zinc-100">
                حفظ سعر السلعة
              </h2>
              <button
                type="button"
                onClick={() => setShowSaveModal(false)}
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"
                aria-label="إغلاق"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
              سعر الكيلو:{' '}
              <span className="font-mono font-semibold text-zinc-900 tabular-nums dark:text-zinc-100">
                {kiloPriceInput}
              </span>{' '}
              {SHEKEL_SYMBOL}
            </p>

            <div className="mt-4">
              <label htmlFor="item-name-input" className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                اسم السلعة
              </label>
              <input
                id="item-name-input"
                type="text"
                autoFocus
                placeholder="مثال: لحم بلدي أو قهوة"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                className="mt-1.5 h-12 w-full rounded-xl border border-zinc-200 bg-[#F7F8F7] px-3.5 text-sm text-zinc-900 placeholder:text-zinc-400 focus:border-[#0D7A5F] focus:bg-white focus:outline-none dark:border-zinc-700 dark:bg-[#0B1110] dark:text-zinc-100 dark:focus:border-emerald-500"
              />
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5">
              {SUGGESTED_ITEM_NAMES.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => setNewItemName(suggestion)}
                  className="min-h-[36px] rounded-lg border border-zinc-200 bg-zinc-50 px-2.5 py-1 text-xs font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:bg-zinc-800"
                >
                  {suggestion}
                </button>
              ))}
            </div>

            <div className="mt-5 flex gap-2">
              <button
                type="submit"
                disabled={!newItemName.trim()}
                className="min-h-[48px] flex-1 rounded-xl bg-[#0D7A5F] px-4 text-sm font-semibold text-white transition-colors hover:bg-[#0A634D] disabled:opacity-50 dark:bg-emerald-600 dark:hover:bg-emerald-500"
              >
                حفظ
              </button>
              <button
                type="button"
                onClick={() => setShowSaveModal(false)}
                className="min-h-[48px] rounded-xl border border-zinc-200 px-4 text-sm font-medium text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      <OfflineIndicator />
    </div>
  );
}
