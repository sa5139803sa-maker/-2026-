import React, {useState} from 'react';
import {BookmarkPlus, Check, Copy, RotateCcw, Scale} from 'lucide-react';
import {
  formatGramPrice,
  formatGramsResult,
  formatNumber,
  normalizeNumericInput,
  parsePositiveNumber,
} from '../utils/formatters';

interface ScaleCalculatorProps {
  kiloPriceInput: string;
  onKiloPriceChange: (value: string) => void;
  targetAmountInput: string;
  onTargetAmountChange: (value: string) => void;
  targetGramsInput: string;
  onTargetGramsChange: (value: string) => void;
  currencySymbol: string;
  onOpenSaveModal: () => void;
}

const QUICK_AMOUNTS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
const QUICK_GRAMS = ['50', '100', '250', '500', '750'];

export const ScaleCalculator: React.FC<ScaleCalculatorProps> = ({
  kiloPriceInput,
  onKiloPriceChange,
  targetAmountInput,
  onTargetAmountChange,
  targetGramsInput,
  onTargetGramsChange,
  currencySymbol,
  onOpenSaveModal,
}) => {
  const [calcMode, setCalcMode] = useState<'price-to-grams' | 'grams-to-price'>('price-to-grams');
  const [copiedField, setCopiedField] = useState<'gram' | 'result' | null>(null);

  const kiloPrice = parsePositiveNumber(kiloPriceInput);
  const pricePerGram = kiloPrice > 0 ? kiloPrice / 1000 : 0;
  const pricePer100Grams = kiloPrice > 0 ? kiloPrice / 10 : 0;

  const targetAmount = parsePositiveNumber(targetAmountInput);
  const calculatedGrams = kiloPrice > 0 && targetAmount > 0 ? (targetAmount / kiloPrice) * 1000 : 0;
  const {gramsText, kiloBreakdown} = formatGramsResult(calculatedGrams);
  const kiloPercentage = calculatedGrams > 0 ? Math.min(100, (calculatedGrams / 1000) * 100) : 0;

  const targetGrams = parsePositiveNumber(targetGramsInput);
  const calculatedPriceForGrams = pricePerGram > 0 && targetGrams > 0 ? targetGrams * pricePerGram : 0;

  const handleCopy = async (text: string, field: 'gram' | 'result') => {
    if (!text || text === '0') return;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      window.setTimeout(() => setCopiedField(null), 1600);
    } catch {
      // Clipboard API unavailable
    }
  };

  const currencyLabel = currencySymbol ? ` ${currencySymbol}` : '';

  return (
    <div className="flex h-full min-h-0 flex-col gap-2 sm:gap-3.5">
      {/* Section 1: Kilo Price Input & Instant Gram Price */}
      <section className="shrink-0 rounded-2xl border border-zinc-200/80 bg-white p-3 shadow-xs sm:rounded-3xl sm:p-5 dark:border-zinc-800 dark:bg-[#131B19]">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <label
              htmlFor="kilo-price-input"
              className="block text-sm font-bold text-zinc-900 sm:text-base dark:text-zinc-100"
            >
              سعر الكيلو بالشيكل (1000 جرام)
            </label>
            <p className="truncate text-[11px] text-zinc-500 sm:text-xs dark:text-zinc-400">
              أدخل سعر الكيلو بالشيكل ليظهر سعر الجرام فوراً
            </p>
          </div>
          {kiloPrice > 0 && (
            <button
              type="button"
              onClick={onOpenSaveModal}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-zinc-200 px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0D7A5F] whitespace-nowrap shrink-0 sm:h-10 sm:px-3 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
            >
              <BookmarkPlus className="h-3.5 w-3.5 text-[#0D7A5F] dark:text-emerald-400" aria-hidden="true" />
              <span>حفظ</span>
            </button>
          )}
        </div>

        <div className="relative mt-2 sm:mt-3">
          <input
            id="kilo-price-input"
            type="text"
            inputMode="decimal"
            dir="ltr"
            autoComplete="off"
            placeholder="0"
            value={kiloPriceInput}
            onChange={(e) => onKiloPriceChange(normalizeNumericInput(e.target.value))}
            className="h-11 w-full rounded-xl border border-zinc-200 bg-[#F7F8F7] px-3.5 pl-20 text-right font-mono text-2xl font-semibold text-zinc-900 tabular-nums transition-colors placeholder:text-zinc-400 focus:border-[#0D7A5F] focus:bg-white focus:outline-none sm:h-14 sm:rounded-2xl sm:text-3xl dark:border-zinc-700/80 dark:bg-[#0B1110] dark:text-zinc-50 dark:placeholder:text-zinc-600 dark:focus:border-emerald-500 dark:focus:bg-[#0F1715]"
          />
          <div className="absolute inset-y-0 left-1.5 flex items-center gap-0.5">
            {currencySymbol && (
              <span className="px-1.5 text-xs font-semibold text-zinc-500 sm:text-sm dark:text-zinc-400">
                {currencySymbol}
              </span>
            )}
            {kiloPriceInput && (
              <button
                type="button"
                onClick={() => onKiloPriceChange('')}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-400 transition-colors hover:bg-zinc-200/60 hover:text-zinc-700 sm:h-10 sm:w-10 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
                aria-label="مسح سعر الكيلو"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {/* Hairline divider + Instant Gram Price Readout */}
        <div className="mt-2.5 flex items-center justify-between gap-3 border-t border-zinc-100 pt-2 sm:mt-4 sm:pt-3.5 dark:border-zinc-800/80">
          <div className="min-w-0">
            <span className="block text-[11px] font-medium text-zinc-500 sm:text-xs dark:text-zinc-400">
              سعر الجرام الواحد
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-2xl font-bold text-[#0D7A5F] tabular-nums sm:text-3xl dark:text-emerald-400">
                {pricePerGram > 0 ? formatGramPrice(pricePerGram) : '0'}
              </span>
              <span className="text-xs font-semibold text-[#0D7A5F]/80 sm:text-sm dark:text-emerald-400/80">
                {currencySymbol ? `${currencySymbol} / جم` : 'لكل جرام'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="text-left">
              <span className="block text-[11px] text-zinc-500 sm:text-xs dark:text-zinc-400">
                100 جرام
              </span>
              <span className="block font-mono text-sm font-semibold text-zinc-800 tabular-nums sm:text-base dark:text-zinc-200">
                {pricePer100Grams > 0 ? `${formatNumber(pricePer100Grams, 2)}${currencyLabel}` : '—'}
              </span>
            </div>

            {pricePerGram > 0 && (
              <button
                type="button"
                onClick={() => handleCopy(formatGramPrice(pricePerGram), 'gram')}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-600 transition-colors hover:bg-zinc-100 active:scale-[0.97] sm:h-10 sm:w-10 dark:border-zinc-700 dark:bg-zinc-800/70 dark:text-zinc-300 dark:hover:bg-zinc-800"
                aria-label="نسخ سعر الجرام"
                title="نسخ سعر الجرام"
              >
                {copiedField === 'gram' ? (
                  <Check className="h-4 w-4 text-[#0D7A5F] dark:text-emerald-400" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Section 2: Calculate Grams from Price (or Reverse) */}
      <section className="flex min-h-0 flex-1 flex-col justify-between rounded-2xl border border-zinc-200/80 bg-white p-3 shadow-xs sm:rounded-3xl sm:p-5 dark:border-zinc-800 dark:bg-[#131B19]">
        <div className="flex min-h-0 flex-1 flex-col justify-between gap-2 sm:gap-3.5">
          {/* Interactive Segmented Control */}
          <div
            className="grid shrink-0 grid-cols-2 gap-1 rounded-xl bg-zinc-100 p-1 dark:bg-zinc-900"
            role="tablist"
            aria-label="طريقة الحساب"
          >
            <button
              type="button"
              role="tab"
              aria-selected={calcMode === 'price-to-grams'}
              onClick={() => setCalcMode('price-to-grams')}
              className={`h-8 rounded-lg px-2 text-xs font-semibold transition-colors whitespace-nowrap sm:h-10 sm:text-sm ${
                calcMode === 'price-to-grams'
                  ? 'bg-white text-zinc-900 shadow-xs dark:bg-[#1B2623] dark:text-zinc-50'
                  : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
              }`}
            >
              أدخل السعر ← كم جرام؟
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={calcMode === 'grams-to-price'}
              onClick={() => setCalcMode('grams-to-price')}
              className={`h-8 rounded-lg px-2 text-xs font-semibold transition-colors whitespace-nowrap sm:h-10 sm:text-sm ${
                calcMode === 'grams-to-price'
                  ? 'bg-white text-zinc-900 shadow-xs dark:bg-[#1B2623] dark:text-zinc-50'
                  : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
              }`}
            >
              أدخل الوزن ← كم السعر؟
            </button>
          </div>

          {calcMode === 'price-to-grams' ? (
            <div className="flex min-h-0 flex-1 flex-col justify-between gap-2 sm:gap-3">
              <div>
                <div className="flex items-center justify-between gap-2">
                  <label
                    htmlFor="target-price-input"
                    className="block text-sm font-bold text-zinc-900 sm:text-base dark:text-zinc-100"
                  >
                    المبلغ بالشيكل
                  </label>
                  <span className="text-[11px] text-zinc-500 sm:text-xs dark:text-zinc-400">
                    مقترح: 1 - 10 ₪
                  </span>
                </div>

                <div className="relative mt-1.5 sm:mt-2">
                  <input
                    id="target-price-input"
                    type="text"
                    inputMode="decimal"
                    dir="ltr"
                    autoComplete="off"
                    placeholder="0"
                    value={targetAmountInput}
                    onChange={(e) => onTargetAmountChange(normalizeNumericInput(e.target.value))}
                    className="h-11 w-full rounded-xl border border-zinc-200 bg-[#F7F8F7] px-3.5 pl-20 text-right font-mono text-xl font-semibold text-zinc-900 tabular-nums transition-colors placeholder:text-zinc-400 focus:border-[#0D7A5F] focus:bg-white focus:outline-none sm:h-13 sm:rounded-2xl sm:text-2xl dark:border-zinc-700/80 dark:bg-[#0B1110] dark:text-zinc-50 dark:placeholder:text-zinc-600 dark:focus:border-emerald-500 dark:focus:bg-[#0F1715]"
                  />
                  <div className="absolute inset-y-0 left-1.5 flex items-center gap-0.5">
                    {currencySymbol && (
                      <span className="px-1.5 text-xs font-semibold text-zinc-500 sm:text-sm dark:text-zinc-400">
                        {currencySymbol}
                      </span>
                    )}
                    {targetAmountInput && (
                      <button
                        type="button"
                        onClick={() => onTargetAmountChange('')}
                        className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-400 transition-colors hover:bg-zinc-200/60 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
                        aria-label="مسح المبلغ"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Quick Tap Amounts 1-10 in a compact 5x2 grid */}
                <div className="mt-1.5 grid grid-cols-5 gap-1.5 sm:mt-2.5 sm:gap-2">
                  {QUICK_AMOUNTS.map((amt) => {
                    const isSelected = targetAmountInput === amt;
                    return (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => onTargetAmountChange(amt)}
                        className={`flex h-9 items-center justify-center rounded-lg border font-mono text-xs font-semibold tabular-nums transition-colors active:scale-[0.97] sm:h-10 sm:rounded-xl sm:text-sm ${
                          isSelected
                            ? 'border-[#0D7A5F] bg-[#0D7A5F] text-white dark:border-emerald-500 dark:bg-emerald-600'
                            : 'border-zinc-200 bg-zinc-50 text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700/80 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800'
                        }`}
                      >
                        {amt}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Result Area */}
              <div className="border-t border-zinc-100 pt-2 sm:pt-3 dark:border-zinc-800/80">
                {kiloPrice <= 0 ? (
                  <div className="flex items-center gap-2 py-1 text-xs text-zinc-500 sm:text-sm dark:text-zinc-400">
                    <Scale className="h-4 w-4 shrink-0 text-zinc-400" aria-hidden="true" />
                    <span>أدخل سعر الكيلو في الأعلى ليظهر الوزن بالجرام تلقائياً.</span>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <span className="block text-[11px] font-medium text-zinc-500 sm:text-xs dark:text-zinc-400">
                          الوزن المستحق مقابل{' '}
                          {targetAmount > 0 ? `${formatNumber(targetAmount, 2)}${currencyLabel}` : 'المبلغ'}
                        </span>
                        <div className="flex flex-wrap items-baseline gap-x-2">
                          <span className="font-mono text-3xl font-bold text-zinc-900 tabular-nums sm:text-4xl dark:text-zinc-50">
                            {calculatedGrams > 0 ? gramsText : '0'}
                          </span>
                          <span className="text-base font-bold text-[#0D7A5F] sm:text-lg dark:text-emerald-400">
                            جرام
                          </span>
                          {kiloBreakdown && (
                            <span className="text-xs font-medium text-zinc-600 dark:text-zinc-300">
                              ({kiloBreakdown})
                            </span>
                          )}
                        </div>
                      </div>

                      {calculatedGrams > 0 && (
                        <button
                          type="button"
                          onClick={() => handleCopy(`${gramsText} جرام`, 'result')}
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-600 transition-colors hover:bg-zinc-100 active:scale-[0.97] sm:h-10 sm:w-10 dark:border-zinc-700 dark:bg-zinc-800/70 dark:text-zinc-300 dark:hover:bg-zinc-800"
                          aria-label="نسخ الوزن"
                          title="نسخ الوزن"
                        >
                          {copiedField === 'result' ? (
                            <Check className="h-4 w-4 text-[#0D7A5F] dark:text-emerald-400" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </button>
                      )}
                    </div>

                    {calculatedGrams > 0 && (
                      <div className="mt-1.5 sm:mt-2">
                        <div className="flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-400">
                          <span>النسبة من الكيلو</span>
                          <span className="font-mono font-medium tabular-nums">
                            {calculatedGrams >= 1000
                              ? `${formatNumber(calculatedGrams / 1000, 2)} كيلو`
                              : `${formatNumber((calculatedGrams / 1000) * 100, 1)}%`}
                          </span>
                        </div>
                        <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-zinc-100 dark:bg-zinc-800">
                          <div
                            className="h-full rounded-full bg-[#0D7A5F] transition-transform duration-200 ease-out dark:bg-emerald-500"
                            style={{width: `${kiloPercentage}%`}}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex min-h-0 flex-1 flex-col justify-between gap-2.5 sm:gap-3">
              <div>
                <div className="flex items-center justify-between gap-2">
                  <label
                    htmlFor="target-grams-input"
                    className="block text-sm font-bold text-zinc-900 sm:text-base dark:text-zinc-100"
                  >
                    الوزن المطلوب بالجرام
                  </label>
                  <span className="text-[11px] text-zinc-500 sm:text-xs dark:text-zinc-400">
                    لمعرفة تكلفة هذا الوزن
                  </span>
                </div>

                <div className="relative mt-2">
                  <input
                    id="target-grams-input"
                    type="text"
                    inputMode="decimal"
                    dir="ltr"
                    autoComplete="off"
                    placeholder="0"
                    value={targetGramsInput}
                    onChange={(e) => onTargetGramsChange(normalizeNumericInput(e.target.value))}
                    className="h-11 w-full rounded-xl border border-zinc-200 bg-[#F7F8F7] px-3.5 pl-20 text-right font-mono text-xl font-semibold text-zinc-900 tabular-nums transition-colors placeholder:text-zinc-400 focus:border-[#0D7A5F] focus:bg-white focus:outline-none sm:h-13 sm:rounded-2xl sm:text-2xl dark:border-zinc-700/80 dark:bg-[#0B1110] dark:text-zinc-50 dark:placeholder:text-zinc-600 dark:focus:border-emerald-500 dark:focus:bg-[#0F1715]"
                  />
                  <div className="absolute inset-y-0 left-1.5 flex items-center gap-0.5">
                    <span className="px-1.5 text-xs font-semibold text-zinc-500 sm:text-sm dark:text-zinc-400">
                      جم
                    </span>
                    {targetGramsInput && (
                      <button
                        type="button"
                        onClick={() => onTargetGramsChange('')}
                        className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-400 transition-colors hover:bg-zinc-200/60 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
                        aria-label="مسح الوزن"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-2 grid grid-cols-5 gap-1.5 sm:gap-2">
                  {QUICK_GRAMS.map((g) => {
                    const isSelected = targetGramsInput === g;
                    return (
                      <button
                        key={g}
                        type="button"
                        onClick={() => onTargetGramsChange(g)}
                        className={`flex h-9 items-center justify-center rounded-lg border font-mono text-xs font-semibold tabular-nums transition-colors active:scale-[0.97] sm:h-10 sm:rounded-xl sm:text-sm ${
                          isSelected
                            ? 'border-[#0D7A5F] bg-[#0D7A5F] text-white dark:border-emerald-500 dark:bg-emerald-600'
                            : 'border-zinc-200 bg-zinc-50 text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700/80 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800'
                        }`}
                      >
                        {g}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="border-t border-zinc-100 pt-2.5 sm:pt-3.5 dark:border-zinc-800/80">
                {kiloPrice <= 0 ? (
                  <div className="flex items-center gap-2.5 py-1 text-xs text-zinc-500 sm:text-sm dark:text-zinc-400">
                    <Scale className="h-4 w-4 shrink-0 text-zinc-400" aria-hidden="true" />
                    <span>أدخل سعر الكيلو في الأعلى ليتم حساب تكلفة الوزن تلقائياً.</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <span className="block text-[11px] font-medium text-zinc-500 sm:text-xs dark:text-zinc-400">
                        سعر {targetGrams > 0 ? `${formatNumber(targetGrams, 1)} جرام` : 'الوزن المحدد'}
                      </span>
                      <div className="mt-0.5 flex items-baseline gap-2">
                        <span className="font-mono text-3xl font-bold text-zinc-900 tabular-nums sm:text-4xl dark:text-zinc-50">
                          {calculatedPriceForGrams > 0 ? formatNumber(calculatedPriceForGrams, 2) : '0'}
                        </span>
                        {currencySymbol && (
                          <span className="text-base font-bold text-[#0D7A5F] sm:text-lg dark:text-emerald-400">
                            {currencySymbol}
                          </span>
                        )}
                      </div>
                    </div>

                    {calculatedPriceForGrams > 0 && (
                      <button
                        type="button"
                        onClick={() => handleCopy(formatNumber(calculatedPriceForGrams, 2), 'result')}
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-600 transition-colors hover:bg-zinc-100 active:scale-[0.97] dark:border-zinc-700 dark:bg-zinc-800/70 dark:text-zinc-300 dark:hover:bg-zinc-800"
                        aria-label="نسخ السعر"
                        title="نسخ السعر"
                      >
                        {copiedField === 'result' ? (
                          <Check className="h-4 w-4 text-[#0D7A5F] dark:text-emerald-400" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
