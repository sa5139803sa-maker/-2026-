import React from 'react';
import {formatGramPrice, formatNumber, parsePositiveNumber} from '../utils/formatters';

interface QuickWeightsPanelProps {
  kiloPriceInput: string;
  currencySymbol: string;
  onSelectAmountFromWeight?: (price: string) => void;
}

const STANDARD_WEIGHTS = [
  {grams: 1, label: '1 جرام', note: 'الجرام الواحد'},
  {grams: 10, label: '10 جرام', note: 'كمية خفيفة'},
  {grams: 50, label: '50 جرام', note: 'كمية صغيرة'},
  {grams: 100, label: '100 جرام', note: 'عُشر الكيلو'},
  {grams: 250, label: '250 جرام', note: 'ربع كيلو'},
  {grams: 500, label: '500 جرام', note: 'نصف كيلو'},
  {grams: 750, label: '750 جرام', note: 'ثلاثة أرباع'},
  {grams: 1000, label: '1000 جرام', note: 'كيلو كامل'},
];

export const QuickWeightsPanel: React.FC<QuickWeightsPanelProps> = ({
  kiloPriceInput,
  currencySymbol,
  onSelectAmountFromWeight,
}) => {
  const kiloPrice = parsePositiveNumber(kiloPriceInput);

  return (
    <section className="flex h-full min-h-0 flex-col rounded-2xl border border-zinc-200/80 bg-white p-3.5 shadow-xs sm:rounded-3xl sm:p-5 dark:border-zinc-800 dark:bg-[#131B19]">
      <div className="shrink-0">
        <h2 className="text-sm font-bold text-zinc-900 sm:text-base dark:text-zinc-100">
          جدول الأوزان السريعة
        </h2>
        <p className="text-[11px] text-zinc-500 sm:text-xs dark:text-zinc-400">
          أسعار الأوزان الشائعة حسب سعر الكيلو الحالي
        </p>
      </div>

      <div className="mt-2.5 flex min-h-0 flex-1 flex-col justify-between divide-y divide-zinc-100 overflow-y-auto dark:divide-zinc-800/80">
        {STANDARD_WEIGHTS.map((row) => {
          const rowPrice = kiloPrice > 0 ? (kiloPrice / 1000) * row.grams : 0;
          const formatted =
            rowPrice <= 0
              ? '—'
              : row.grams === 1
                ? formatGramPrice(rowPrice)
                : formatNumber(rowPrice, 2);

          return (
            <button
              key={row.grams}
              type="button"
              disabled={kiloPrice <= 0}
              onClick={() => {
                if (rowPrice > 0 && onSelectAmountFromWeight) {
                  onSelectAmountFromWeight(
                    row.grams === 1 ? formatGramPrice(rowPrice) : String(Number(rowPrice.toFixed(2))),
                  );
                }
              }}
              className="flex min-h-[38px] flex-1 w-full items-center justify-between gap-2 py-1 text-right transition-colors hover:bg-zinc-50/80 disabled:cursor-default disabled:hover:bg-transparent dark:hover:bg-zinc-800/40"
            >
              <div className="flex items-baseline gap-2 min-w-0">
                <span className="text-xs font-semibold text-zinc-900 sm:text-sm dark:text-zinc-100">
                  {row.label}
                </span>
                <span className="truncate text-[11px] text-zinc-500 dark:text-zinc-400">
                  · {row.note}
                </span>
              </div>
              <div className="shrink-0 text-left">
                <span className="font-mono text-sm font-semibold text-zinc-900 tabular-nums sm:text-base dark:text-zinc-100">
                  {formatted}
                </span>
                {kiloPrice > 0 && currencySymbol && (
                  <span className="mr-1 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                    {currencySymbol}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};
