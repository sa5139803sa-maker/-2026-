import React from 'react';
import {Bookmark, Trash2} from 'lucide-react';
import {formatGramPrice, formatNumber} from '../utils/formatters';

export interface SavedItem {
  id: string;
  name: string;
  kiloPrice: number;
}

interface SavedItemsPanelProps {
  items: SavedItem[];
  currencySymbol: string;
  activeKiloPrice: number;
  onSelectItem: (item: SavedItem) => void;
  onDeleteItem: (id: string) => void;
}

export const SavedItemsPanel: React.FC<SavedItemsPanelProps> = ({
  items,
  currencySymbol,
  activeKiloPrice,
  onSelectItem,
  onDeleteItem,
}) => {
  return (
    <section className="flex h-full min-h-0 flex-col rounded-2xl border border-zinc-200/80 bg-white p-3.5 shadow-xs sm:rounded-3xl sm:p-5 dark:border-zinc-800 dark:bg-[#131B19]">
      <div className="shrink-0">
        <h2 className="text-sm font-bold text-zinc-900 sm:text-base dark:text-zinc-100">
          الأسعار المحفوظة
        </h2>
        <p className="text-[11px] text-zinc-500 sm:text-xs dark:text-zinc-400">
          اضغط على أي سلعة لتطبيق سعر الكيلو الخاص بها فوراً
        </p>
      </div>

      {items.length === 0 ? (
        <div className="mt-3 flex flex-1 flex-col items-center justify-center rounded-2xl border border-dashed border-zinc-200 px-4 py-6 text-center dark:border-zinc-800">
          <Bookmark className="h-5 w-5 text-zinc-400" aria-hidden="true" />
          <p className="mt-2 text-xs font-medium text-zinc-700 sm:text-sm dark:text-zinc-300">
            لا توجد سلع محفوظة بعد
          </p>
          <p className="mt-1 text-[11px] text-zinc-500 sm:text-xs dark:text-zinc-400">
            أدخل سعر الكيلو لأي سلعة واضغط «حفظ» للوصول إليها لاحقاً.
          </p>
        </div>
      ) : (
        <ul className="mt-2.5 min-h-0 flex-1 divide-y divide-zinc-100 overflow-y-auto dark:divide-zinc-800/80">
          {items.map((item) => {
            const isActive = Math.abs(activeKiloPrice - item.kiloPrice) < 0.001;
            const gramPrice = item.kiloPrice / 1000;

            return (
              <li key={item.id} className="flex items-center justify-between gap-2 py-1">
                <button
                  type="button"
                  onClick={() => onSelectItem(item)}
                  className={`flex min-h-[44px] flex-1 items-center justify-between gap-2 rounded-xl px-2.5 py-1.5 text-right transition-colors ${
                    isActive
                      ? 'bg-[#0D7A5F]/10 text-[#0D7A5F] dark:bg-emerald-500/15 dark:text-emerald-300'
                      : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/50'
                  }`}
                >
                  <div className="min-w-0">
                    <span className="block truncate text-xs font-semibold text-zinc-900 sm:text-sm dark:text-zinc-100">
                      {item.name}
                    </span>
                    <span className="block text-[11px] text-zinc-500 tabular-nums dark:text-zinc-400">
                      الجرام: {formatGramPrice(gramPrice)}
                      {currencySymbol ? ` ${currencySymbol}` : ''}
                    </span>
                  </div>
                  <div className="shrink-0 text-left">
                    <span className="font-mono text-xs font-bold text-zinc-900 tabular-nums sm:text-sm dark:text-zinc-100">
                      {formatNumber(item.kiloPrice, 2)}
                    </span>
                    {currencySymbol && (
                      <span className="mr-1 text-[11px] text-zinc-500 dark:text-zinc-400">
                        {currencySymbol}
                      </span>
                    )}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onDeleteItem(item.id)}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-zinc-400 transition-colors hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                  aria-label={`حذف ${item.name}`}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
};
