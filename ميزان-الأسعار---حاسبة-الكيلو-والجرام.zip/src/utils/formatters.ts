export const SHEKEL_SYMBOL = '₪';

const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

export function normalizeNumericInput(raw: string): string {
  let out = '';
  let hasDot = false;

  for (const ch of raw) {
    const arIdx = ARABIC_DIGITS.indexOf(ch);
    if (arIdx !== -1) {
      out += String(arIdx);
      continue;
    }
    const faIdx = PERSIAN_DIGITS.indexOf(ch);
    if (faIdx !== -1) {
      out += String(faIdx);
      continue;
    }
    if (ch >= '0' && ch <= '9') {
      out += ch;
      continue;
    }
    if ((ch === '.' || ch === ',' || ch === '٫') && !hasDot) {
      out += out === '' ? '0.' : '.';
      hasDot = true;
    }
  }

  return out;
}

export function parsePositiveNumber(value: string): number {
  if (!value) return 0;
  const num = Number.parseFloat(value);
  if (!Number.isFinite(num) || num <= 0) return 0;
  return num;
}

export function formatNumber(num: number, maxDecimals = 2): string {
  if (!Number.isFinite(num) || num <= 0) return '0';
  const rounded = Number(num.toFixed(maxDecimals));
  return rounded.toLocaleString('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: maxDecimals,
  });
}

export function formatGramPrice(pricePerGram: number): string {
  if (!Number.isFinite(pricePerGram) || pricePerGram <= 0) return '0';
  if (pricePerGram < 0.01) {
    return formatNumber(pricePerGram, 4);
  }
  if (pricePerGram < 1) {
    return formatNumber(pricePerGram, 3);
  }
  return formatNumber(pricePerGram, 2);
}

export function formatGramsResult(grams: number): {
  gramsText: string;
  kiloBreakdown: string | null;
} {
  if (!Number.isFinite(grams) || grams <= 0) {
    return {gramsText: '0', kiloBreakdown: null};
  }

  const gramsText = grams < 10 ? formatNumber(grams, 2) : formatNumber(grams, 1);

  if (grams >= 1000) {
    const kilos = Math.floor(grams / 1000);
    const remGrams = Math.round(grams - kilos * 1000);
    if (remGrams === 0) {
      return {
        gramsText,
        kiloBreakdown: `${kilos.toLocaleString('en-US')} كيلو بالضبط`,
      };
    }
    return {
      gramsText,
      kiloBreakdown: `${kilos.toLocaleString('en-US')} كيلو و ${remGrams.toLocaleString('en-US')} جرام`,
    };
  }

  return {gramsText, kiloBreakdown: null};
}
