# Keep app classes and JSON serialization intact
-keep class com.mizan.pricecalc.** { *; }
