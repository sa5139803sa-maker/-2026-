package com.mizan.pricecalc

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.floor
import kotlin.math.roundToInt

const val SHEKEL_SYMBOL = "₪"

data class SavedItem(
    val id: String,
    val name: String,
    val kiloPrice: Double
)

data class GramsDisplay(
    val gramsText: String,
    val kiloBreakdown: String?
)

private val ARABIC_DIGITS = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
private val PERSIAN_DIGITS = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

fun normalizeNumericInput(raw: String): String {
    val sb = StringBuilder()
    var hasDot = false

    for (ch in raw) {
        val arIdx = ARABIC_DIGITS.indexOf(ch)
        if (arIdx != -1) {
            sb.append(arIdx)
            continue
        }
        val faIdx = PERSIAN_DIGITS.indexOf(ch)
        if (faIdx != -1) {
            sb.append(faIdx)
            continue
        }
        if (ch in '0'..'9') {
            sb.append(ch)
            continue
        }
        if ((ch == '.' || ch == ',' || ch == '٫') && !hasDot) {
            if (sb.isEmpty()) sb.append('0')
            sb.append('.')
            hasDot = true
        }
    }
    return sb.toString()
}

fun parsePositiveDouble(value: String): Double {
    val parsed = value.toDoubleOrNull() ?: return 0.0
    return if (parsed.isFinite() && parsed > 0.0) parsed else 0.0
}

fun formatNumber(value: Double, maxDecimals: Int = 2): String {
    if (!value.isFinite() || value <= 0.0) return "0"
    val pattern = if (maxDecimals <= 0) "#,##0" else "#,##0." + "#".repeat(maxDecimals)
    val symbols = DecimalFormatSymbols(Locale.US)
    val df = DecimalFormat(pattern, symbols)
    return df.format(value)
}

fun formatGramPrice(pricePerGram: Double): String {
    if (!pricePerGram.isFinite() || pricePerGram <= 0.0) return "0"
    return when {
        pricePerGram < 0.01 -> formatNumber(pricePerGram, 4)
        pricePerGram < 1.0 -> formatNumber(pricePerGram, 3)
        else -> formatNumber(pricePerGram, 2)
    }
}

fun formatGramsResult(grams: Double): GramsDisplay {
    if (!grams.isFinite() || grams <= 0.0) {
        return GramsDisplay(gramsText = "0", kiloBreakdown = null)
    }
    val gramsText = if (grams < 10.0) formatNumber(grams, 2) else formatNumber(grams, 1)

    if (grams >= 1000.0) {
        val kilos = floor(grams / 1000.0).toInt()
        val remGrams = (grams - kilos * 1000.0).roundToInt()
        val breakdown = if (remGrams == 0) {
            "$kilos كيلو بالضبط"
        } else {
            "$kilos كيلو و $remGrams جرام"
        }
        return GramsDisplay(gramsText = gramsText, kiloBreakdown = breakdown)
    }

    return GramsDisplay(gramsText = gramsText, kiloBreakdown = null)
}

object MizanStorage {
    private const val PREFS_NAME = "mizan_prefs"
    private const val KEY_KILO_PRICE = "kilo_price"
    private const val KEY_TARGET_AMOUNT = "target_amount"
    private const val KEY_DARK_MODE = "dark_mode"
    private const val KEY_SAVED_ITEMS = "saved_items"

    fun loadKiloPrice(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_KILO_PRICE, "") ?: ""

    fun saveKiloPrice(context: Context, value: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_KILO_PRICE, value).apply()
    }

    fun loadTargetAmount(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TARGET_AMOUNT, "") ?: ""

    fun saveTargetAmount(context: Context, value: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_TARGET_AMOUNT, value).apply()
    }

    fun loadDarkMode(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_DARK_MODE, false)

    fun saveDarkMode(context: Context, isDark: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DARK_MODE, isDark).apply()
    }

    fun loadSavedItems(context: Context): List<SavedItem> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SAVED_ITEMS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        SavedItem(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            kiloPrice = obj.getDouble("kiloPrice")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveItems(context: Context, items: List<SavedItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("kiloPrice", item.kiloPrice)
                }
            )
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_SAVED_ITEMS, arr.toString()).apply()
    }
}
