package com.mizan.pricecalc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Scale
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val EmeraldLight = Color(0xFF0D7A5F)
private val EmeraldDark = Color(0xFF10B981)
private val CanvasLight = Color(0xFFF7F8F7)
private val SurfaceLight = Color(0xFFFFFFFF)
private val CanvasDark = Color(0xFF0B1110)
private val SurfaceDark = Color(0xFF131B19)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MizanApp()
        }
    }
}

@Composable
fun MizanApp() {
    val context = LocalContext.current
    var isDark by remember { mutableStateOf(MizanStorage.loadDarkMode(context)) }
    var kiloPriceInput by remember { mutableStateOf(MizanStorage.loadKiloPrice(context)) }
    var targetAmountInput by remember { mutableStateOf(MizanStorage.loadTargetAmount(context)) }
    var targetGramsInput by remember { mutableStateOf("250") }
    var savedItems by remember { mutableStateOf(MizanStorage.loadSavedItems(context)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showSaveDialog by remember { mutableStateOf(false) }

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = EmeraldDark,
            onPrimary = Color.Black,
            background = CanvasDark,
            onBackground = Color(0xFFF4F4F5),
            surface = SurfaceDark,
            onSurface = Color(0xFFF4F4F5),
            surfaceVariant = Color(0xFF1B2623),
            outline = Color(0xFF273430)
        )
    } else {
        lightColorScheme(
            primary = EmeraldLight,
            onPrimary = Color.White,
            background = CanvasLight,
            onBackground = Color(0xFF18181B),
            surface = SurfaceLight,
            onSurface = Color(0xFF18181B),
            surfaceVariant = Color(0xFFF4F4F5),
            outline = Color(0xFFE4E4E7)
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = colorScheme) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp,
                        shadowElevation = 0.dp
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Scale,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Text(
                                        text = "ميزان الأسعار",
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "شيكل ($SHEKEL_SYMBOL)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                                    )
                                    IconButton(
                                        onClick = {
                                            isDark = !isDark
                                            MizanStorage.saveDarkMode(context, isDark)
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (isDark) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                                            contentDescription = "تبديل المظهر",
                                            tint = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        }
                    }
                },
                bottomBar = {
                    Surface(color = MaterialTheme.colorScheme.surface) {
                        Column {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 0.dp,
                                modifier = Modifier.height(64.dp)
                            ) {
                                NavigationBarItem(
                                    selected = selectedTab == 0,
                                    onClick = { selectedTab = 0 },
                                    icon = {
                                        Icon(Icons.Outlined.Calculate, contentDescription = null)
                                    },
                                    label = {
                                        Text("الحاسبة", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    )
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 1,
                                    onClick = { selectedTab = 1 },
                                    icon = {
                                        Icon(Icons.Outlined.TableChart, contentDescription = null)
                                    },
                                    label = {
                                        Text("جدول الأوزان", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    )
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 2,
                                    onClick = { selectedTab = 2 },
                                    icon = {
                                        Icon(Icons.Outlined.Bookmark, contentDescription = null)
                                    },
                                    label = {
                                        val countSuffix = if (savedItems.isNotEmpty()) " (${savedItems.size})" else ""
                                        Text("المحفوظات$countSuffix", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    when (selectedTab) {
                        0 -> CalculatorScreen(
                            kiloPriceInput = kiloPriceInput,
                            onKiloPriceChange = {
                                kiloPriceInput = it
                                MizanStorage.saveKiloPrice(context, it)
                            },
                            targetAmountInput = targetAmountInput,
                            onTargetAmountChange = {
                                targetAmountInput = it
                                MizanStorage.saveTargetAmount(context, it)
                            },
                            targetGramsInput = targetGramsInput,
                            onTargetGramsChange = { targetGramsInput = it },
                            onOpenSave = { showSaveDialog = true }
                        )

                        1 -> QuickWeightsScreen(
                            kiloPriceInput = kiloPriceInput,
                            onSelectPrice = { price ->
                                targetAmountInput = price
                                MizanStorage.saveTargetAmount(context, price)
                                selectedTab = 0
                            }
                        )

                        2 -> SavedItemsScreen(
                            items = savedItems,
                            activeKiloPrice = parsePositiveDouble(kiloPriceInput),
                            onSelectItem = { item ->
                                val str = formatNumber(item.kiloPrice, 2).replace(",", "")
                                kiloPriceInput = str
                                MizanStorage.saveKiloPrice(context, str)
                                selectedTab = 0
                            },
                            onDeleteItem = { id ->
                                savedItems = savedItems.filterNot { it.id == id }
                                MizanStorage.saveItems(context, savedItems)
                            }
                        )
                    }
                }
            }

            if (showSaveDialog) {
                SaveItemDialog(
                    kiloPrice = parsePositiveDouble(kiloPriceInput),
                    onDismiss = { showSaveDialog = false },
                    onSave = { name ->
                        val price = parsePositiveDouble(kiloPriceInput)
                        if (price > 0.0 && name.isNotBlank()) {
                            val newItem = SavedItem(
                                id = System.currentTimeMillis().toString(),
                                name = name.trim(),
                                kiloPrice = price
                            )
                            savedItems = listOf(newItem) + savedItems
                            MizanStorage.saveItems(context, savedItems)
                        }
                        showSaveDialog = false
                    }
                )
            }
        }
    }
}

@Composable
private fun CalculatorScreen(
    kiloPriceInput: String,
    onKiloPriceChange: (String) -> Unit,
    targetAmountInput: String,
    onTargetAmountChange: (String) -> Unit,
    targetGramsInput: String,
    onTargetGramsChange: (String) -> Unit,
    onOpenSave: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var calcModePriceToGrams by remember { mutableStateOf(true) }
    var copiedTag by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(copiedTag) {
        if (copiedTag != null) {
            delay(1500)
            copiedTag = null
        }
    }

    val kiloPrice = parsePositiveDouble(kiloPriceInput)
    val pricePerGram = if (kiloPrice > 0.0) kiloPrice / 1000.0 else 0.0
    val pricePer100Grams = if (kiloPrice > 0.0) kiloPrice / 10.0 else 0.0

    val targetAmount = parsePositiveDouble(targetAmountInput)
    val calculatedGrams = if (kiloPrice > 0.0 && targetAmount > 0.0) (targetAmount / kiloPrice) * 1000.0 else 0.0
    val gramsDisplay = formatGramsResult(calculatedGrams)
    val kiloProgress = if (calculatedGrams > 0.0) (calculatedGrams / 1000.0).toFloat().coerceIn(0f, 1f) else 0f

    val targetGrams = parsePositiveDouble(targetGramsInput)
    val calculatedPriceForGrams = if (pricePerGram > 0.0 && targetGrams > 0.0) targetGrams * pricePerGram else 0.0

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Card 1: Kilo price -> Gram price
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "سعر الكيلو بالشيكل (1000 جرام)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "أدخل سعر الكيلو ليظهر سعر الجرام فوراً",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (kiloPrice > 0.0) {
                        OutlinedButton(
                            onClick = onOpenSave,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.BookmarkAdd,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حفظ", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                OutlinedTextField(
                    value = kiloPriceInput,
                    onValueChange = { onKiloPriceChange(normalizeNumericInput(it)) },
                    placeholder = {
                        Text(
                            "0",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 22.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.End
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    textStyle = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.End,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = SHEKEL_SYMBOL,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                            if (kiloPriceInput.isNotEmpty()) {
                                IconButton(onClick = { onKiloPriceChange("") }) {
                                    Icon(
                                        imageVector = Icons.Outlined.Refresh,
                                        contentDescription = "مسح"
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.width(12.dp))
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.background,
                        unfocusedContainerColor = MaterialTheme.colorScheme.background,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "سعر الجرام الواحد",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = if (pricePerGram > 0.0) formatGramPrice(pricePerGram) else "0",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$SHEKEL_SYMBOL / جم",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                modifier = Modifier.padding(bottom = 3.dp)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "100 جرام",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                            Text(
                                text = if (pricePer100Grams > 0.0) "${formatNumber(pricePer100Grams, 2)} $SHEKEL_SYMBOL" else "—",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (pricePerGram > 0.0) {
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(formatGramPrice(pricePerGram)))
                                    copiedTag = "gram"
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = if (copiedTag == "gram") Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                                    contentDescription = "نسخ سعر الجرام",
                                    tint = if (copiedTag == "gram") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Card 2: Price -> Grams (fits remaining height without scrolling)
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Mode Switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ModeTabButton(
                        text = "أدخل السعر ← كم جرام؟",
                        selected = calcModePriceToGrams,
                        onClick = { calcModePriceToGrams = true },
                        modifier = Modifier.weight(1f)
                    )
                    ModeTabButton(
                        text = "أدخل الوزن ← كم السعر؟",
                        selected = !calcModePriceToGrams,
                        onClick = { calcModePriceToGrams = false },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (calcModePriceToGrams) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "المبلغ بالشيكل",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "مقترح: 1 - 10 $SHEKEL_SYMBOL",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }

                        OutlinedTextField(
                            value = targetAmountInput,
                            onValueChange = { onTargetAmountChange(normalizeNumericInput(it)) },
                            placeholder = {
                                Text(
                                    "0",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 20.sp,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.End
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.End,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            trailingIcon = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = SHEKEL_SYMBOL,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                    )
                                    if (targetAmountInput.isNotEmpty()) {
                                        IconButton(onClick = { onTargetAmountChange("") }) {
                                            Icon(Icons.Outlined.Refresh, contentDescription = "مسح")
                                        }
                                    } else {
                                        Spacer(modifier = Modifier.width(12.dp))
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.background,
                                unfocusedContainerColor = MaterialTheme.colorScheme.background,
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Quick amounts 1-10 in 2 rows of 5
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf(listOf("1", "2", "3", "4", "5"), listOf("6", "7", "8", "9", "10")).forEach { rowAmounts ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    rowAmounts.forEach { amt ->
                                        val isSelected = targetAmountInput == amt
                                        Surface(
                                            shape = RoundedCornerShape(9.dp),
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                            ),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(36.dp)
                                                .clip(RoundedCornerShape(9.dp))
                                                .clickable { onTargetAmountChange(amt) }
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = amt,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Grams Result
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
                        if (kiloPrice <= 0.0) {
                            Text(
                                text = "أدخل سعر الكيلو في الأعلى ليظهر الوزن بالجرام تلقائياً.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    val amountText = if (targetAmount > 0.0) "${formatNumber(targetAmount, 2)} $SHEKEL_SYMBOL" else "المبلغ"
                                    Text(
                                        text = "الوزن المستحق مقابل $amountText",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                    )
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = if (calculatedGrams > 0.0) gramsDisplay.gramsText else "0",
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 28.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "جرام",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(bottom = 3.dp)
                                        )
                                        if (gramsDisplay.kiloBreakdown != null) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "(${gramsDisplay.kiloBreakdown})",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                                                modifier = Modifier.padding(bottom = 4.dp)
                                            )
                                        }
                                    }
                                }

                                if (calculatedGrams > 0.0) {
                                    IconButton(
                                        onClick = {
                                            clipboard.setText(AnnotatedString("${gramsDisplay.gramsText} جرام"))
                                            copiedTag = "result"
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (copiedTag == "result") Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                                            contentDescription = "نسخ الوزن",
                                            tint = if (copiedTag == "result") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                        )
                                    }
                                }
                            }

                            if (calculatedGrams > 0.0) {
                                LinearProgressIndicator(
                                    progress = { kiloProgress },
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(99.dp))
                                )
                            }
                        }
                    }
                } else {
                    // Grams -> Price mode
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "الوزن المطلوب بالجرام",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        OutlinedTextField(
                            value = targetGramsInput,
                            onValueChange = { onTargetGramsChange(normalizeNumericInput(it)) },
                            placeholder = {
                                Text(
                                    "0",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 20.sp,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.End
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.End,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            trailingIcon = {
                                Text(
                                    text = "جم",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                    modifier = Modifier.padding(end = 12.dp)
                                )
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.background,
                                unfocusedContainerColor = MaterialTheme.colorScheme.background,
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            listOf("50", "100", "250", "500", "750").forEach { g ->
                                val isSelected = targetGramsInput == g
                                Surface(
                                    shape = RoundedCornerShape(9.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clip(RoundedCornerShape(9.dp))
                                        .clickable { onTargetGramsChange(g) }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = g,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
                        if (kiloPrice <= 0.0) {
                            Text(
                                text = "أدخل سعر الكيلو في الأعلى ليتم حساب تكلفة الوزن تلقائياً.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        } else {
                            val weightLabel = if (targetGrams > 0.0) "${formatNumber(targetGrams, 1)} جرام" else "الوزن المحدد"
                            Text(
                                text = "سعر $weightLabel",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = if (calculatedPriceForGrams > 0.0) formatNumber(calculatedPriceForGrams, 2) else "0",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = SHEKEL_SYMBOL,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(bottom = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeTabButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (selected) MaterialTheme.colorScheme.surface else Color.Transparent,
        shadowElevation = if (selected) 1.dp else 0.dp,
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 6.dp)) {
            Text(
                text = text,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
        }
    }
}

@Composable
private fun QuickWeightsScreen(
    kiloPriceInput: String,
    onSelectPrice: (String) -> Unit
) {
    val kiloPrice = parsePositiveDouble(kiloPriceInput)
    val weights = listOf(
        1 to "الجرام الواحد",
        10 to "كمية خفيفة",
        50 to "كمية صغيرة",
        100 to "عُشر الكيلو",
        250 to "ربع كيلو",
        500 to "نصف كيلو",
        750 to "ثلاثة أرباع",
        1000 to "كيلو كامل"
    )

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "جدول الأوزان السريعة",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "أسعار الأوزان الشائعة بالشيكل حسب سعر الكيلو الحالي",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
            Spacer(modifier = Modifier.height(10.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                weights.forEachIndexed { idx, (grams, note) ->
                    val price = if (kiloPrice > 0.0) (kiloPrice / 1000.0) * grams else 0.0
                    val priceText = when {
                        price <= 0.0 -> "—"
                        grams == 1 -> "${formatGramPrice(price)} $SHEKEL_SYMBOL"
                        else -> "${formatNumber(price, 2)} $SHEKEL_SYMBOL"
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clickable(enabled = kiloPrice > 0.0) {
                                if (price > 0.0) {
                                    val raw = if (grams == 1) formatGramPrice(price) else formatNumber(price, 2)
                                    onSelectPrice(raw.replace(",", ""))
                                }
                            }
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$grams جرام",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = " · $note",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Text(
                            text = priceText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (idx < weights.lastIndex) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedItemsScreen(
    items: List<SavedItem>,
    activeKiloPrice: Double,
    onSelectItem: (SavedItem) -> Unit,
    onDeleteItem: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "الأسعار المحفوظة",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "اضغط على أي سلعة لتطبيق سعر الكيلو الخاص بها فوراً",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (items.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.Bookmark,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا توجد سلع محفوظة بعد",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "أدخل سعر الكيلو لأي سلعة واضغط «حفظ» للوصول إليها لاحقاً.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(items, key = { it.id }) { item ->
                        val isActive = kotlin.math.abs(activeKiloPrice - item.kiloPrice) < 0.001
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.background,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onSelectItem(item) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "الجرام: ${formatGramPrice(item.kiloPrice / 1000.0)} $SHEKEL_SYMBOL",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${formatNumber(item.kiloPrice, 2)} $SHEKEL_SYMBOL",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    IconButton(onClick = { onDeleteItem(item.id) }) {
                                        Icon(
                                            imageVector = Icons.Outlined.DeleteOutline,
                                            contentDescription = "حذف ${item.name}",
                                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SaveItemDialog(
    kiloPrice: Double,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    val suggestions = listOf("لحم", "دجاج", "قهوة", "جبن", "مكسرات")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("حفظ سعر السلعة", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "سعر الكيلو: ${formatNumber(kiloPrice, 2)} $SHEKEL_SYMBOL",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم السلعة") },
                    placeholder = { Text("مثال: لحم بلدي أو قهوة") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    suggestions.take(4).forEach { s ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { name = s }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(s, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name) },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
